"""
语义一致性检查模块
检查论文元数据中的标题和年份字段是否合理。
"""

import re
import string
from dataclasses import dataclass, field
from typing import List


# ============================================================
# 配置：检查阈值（可根据实际需求调整）
# ============================================================

TITLE_MIN_LEN = 5        # 标题最短字符数（太短说明可能是截断或缺失）
TITLE_MAX_LEN = 300      # 标题最长字符数（太长可能是拼接错误）
YEAR_MIN = 1900          # 年份下限
YEAR_MAX = 2026          # 年份上限

# 无意义字符：不可打印字符（\x00-\x1f、\x7f）和控制字符
GARBAGE_PATTERN = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]')
# 全篇都是特殊符号的标题（几乎没有字母/数字/中文）
ALL_SPECIAL_PATTERN = re.compile(r'^[^\w一-鿿]+$')
# 连续重复字符过多（如 "aaaaaaa" 或 "---------"）
REPEAT_PATTERN = re.compile(r'(.)\1{9,}')  # 同一字符连续出现 10 次以上


@dataclass
class CheckResult:
    """单条检查结果"""
    index: int              # 原始数据中的行号/序号
    passed: bool            # 是否通过全部检查
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


# ============================================================
# 检查 1：标题长度
# ============================================================

def check_title_length(title: str) -> List[str]:
    """检查标题长度是否在合理范围内。返回问题列表（空列表表示通过）。"""
    problems = []
    if title is None:
        problems.append("标题为空（None）")
        return problems

    length = len(title.strip())
    if length == 0:
        problems.append("标题为空字符串")
    elif length < TITLE_MIN_LEN:
        problems.append(f"标题过短（{length} 字符，最小 {TITLE_MIN_LEN}）")
    elif length > TITLE_MAX_LEN:
        problems.append(f"标题过长（{length} 字符，最大 {TITLE_MAX_LEN}）")
    return problems


# ============================================================
# 检查 2：无意义字符
# ============================================================

def check_garbage_chars(title: str) -> List[str]:
    """检查标题中是否包含无意义字符。返回问题列表（空列表表示通过）。"""
    problems = []
    if not title or not title.strip():
        return problems  # 空标题由 check_title_length 处理

    title = title.strip()

    # 2a. 不可打印控制字符
    garbage_matches = GARBAGE_PATTERN.findall(title)
    if garbage_matches:
        # 用 repr 展示不可见字符
        shown = ', '.join(repr(c) for c in set(garbage_matches))
        problems.append(f"标题包含不可打印字符：{shown}")

    # 2b. 全是特殊符号，没有实际内容
    if ALL_SPECIAL_PATTERN.match(title):
        problems.append(f"标题全由特殊符号组成，无实际文字内容")

    # 2c. 连续重复字符（可能是数据损坏）
    repeat_match = REPEAT_PATTERN.search(title)
    if repeat_match:
        problems.append(f"标题包含连续重复字符：'{repeat_match.group(0)}'")

    # 2d. 可打印但高度可疑的字符比例
    #     如果非字母非数字非中文非常见标点的字符超过 50%，发出警告
    normal_chars = set(string.ascii_letters + string.digits + string.whitespace)
    abnormal_count = sum(
        1 for c in title
        if c not in normal_chars
        and not ('一' <= c <= '鿿')   # 中文
        and c not in '，。！？；：""''（）【】《》、…—·'  # 常见中文标点
    )
    if len(title) > 0 and abnormal_count / len(title) > 0.5:
        problems.append(f"标题中异常字符占比过高（{abnormal_count}/{len(title)}）")

    return problems


# ============================================================
# 检查 3：年份范围
# ============================================================

def check_year_range(year) -> List[str]:
    """检查年份是否在合理范围内。支持 int、str、float 类型。返回问题列表。"""
    problems = []
    if year is None:
        problems.append("年份缺失")
        return problems

    try:
        year_int = int(year)
    except (ValueError, TypeError):
        problems.append(f"年份格式无法解析：'{year}'")
        return problems

    if year_int < YEAR_MIN:
        problems.append(f"年份过早（{year_int}，合理范围 {YEAR_MIN}-{YEAR_MAX}）")
    elif year_int > YEAR_MAX:
        problems.append(f"年份过晚（{year_int}，合理范围 {YEAR_MIN}-{YEAR_MAX}）")
    return problems


# ============================================================
# 综合检查入口
# ============================================================

def check_single(title: str, year, index: int = 0) -> CheckResult:
    """对单条记录执行全部三项语义一致性检查。

    Args:
        title: 论文标题
        year:  发表年份（int、str 或 None）
        index: 记录序号（用于定位）

    Returns:
        CheckResult：包含是否通过及所有错误/警告信息
    """
    errors = []
    errors.extend(check_title_length(title))
    errors.extend(check_garbage_chars(title))
    errors.extend(check_year_range(year))

    return CheckResult(
        index=index,
        passed=len(errors) == 0,
        errors=errors,
    )


def check_batch(records: List[dict]) -> List[CheckResult]:
    """批量检查多条记录。

    Args:
        records: 列表，每条为 dict，至少包含 'title' 和 'year' 键

    Returns:
        CheckResult 列表
    """
    results = []
    for i, rec in enumerate(records):
        result = check_single(
            title=rec.get('title'),
            year=rec.get('year'),
            index=i,
        )
        results.append(result)
    return results


def report(results: List[CheckResult]) -> str:
    """生成可读的检查报告。"""
    total = len(results)
    passed = sum(1 for r in results if r.passed)
    failed = total - passed

    lines = [
        "=" * 60,
        "语义一致性检查报告",
        "=" * 60,
        f"检查总数：{total}",
        f"通过：{passed}",
        f"未通过：{failed}",
        "",
    ]

    if failed > 0:
        lines.append("--- 未通过记录详情 ---")
        for r in results:
            if not r.passed:
                lines.append(f"\n[记录 #{r.index + 1}]")
                for err in r.errors:
                    lines.append(f"  [FAIL] {err}")

    lines.append("\n" + "=" * 60)
    return '\n'.join(lines)


# ============================================================
# 原始引用文本解析（支持直接粘贴知网/万方/CSSCI 引用格式）
# ============================================================

# 匹配标题：最后一个英文句号(或中文句号)到 [类型标记] 之间的内容
# 知网类型码：J=期刊 N=报纸 D=学位 M=专著 C=会议 R=报告 P=专利
REF_TYPE_CODES = 'J|N|D|M|C|R|P'
TITLE_PATTERN = re.compile(r'([.。])\s*([^.。]+?)\s*\[(' + REF_TYPE_CODES + r')\]')

# 匹配年份：四位数字 19xx 或 20xx
YEAR_PATTERN = re.compile(r'(19\d{2}|20\d{2})')


def parse_single_reference(text: str) -> dict:
    """从单条知网引用文本中提取标题和年份。

    支持的格式示例:
        [1]作者.标题[J].期刊名,2022,(7):156-159.
        [1]作者.标题[N].报纸名,2025-01-09(001).
        [1]作者.标题[D].学校,2023.

    Args:
        text: 一条完整的引用文本

    Returns:
        {'title': str|None, 'year': int|None, 'raw': 原始文本}
    """
    raw = text.strip()
    title = None
    year = None

    # 步骤1：提取标题 — 找到 .标题[类型] 模式
    # 用 finditer 找所有匹配，取最后一个（因为标题内部可能有缩写加点）
    matches = list(TITLE_PATTERN.finditer(raw))
    if matches:
        title = matches[-1].group(2).strip()
        # 从类型标记之后开始找年份
        after_type = raw[matches[-1].end():]
    else:
        after_type = raw

    # 步骤2：从类型标记之后提取年份
    year_match = YEAR_PATTERN.search(after_type)
    if year_match:
        year = int(year_match.group(1))

    return {'title': title, 'year': year, 'raw': raw}


def parse_references_batch(text: str) -> list:
    """批量解析引用文本（每行一条），自动跳过空行。

    Args:
        text: 多行引用文本，一行一条

    Returns:
        解析后的记录列表 [{'title': ..., 'year': ..., 'raw': ...}, ...]
    """
    records = []
    for line in text.strip().split('\n'):
        line = line.strip()
        if not line:
            continue
        parsed = parse_single_reference(line)
        records.append(parsed)
    return records


# ============================================================
# 运行入口
# ============================================================

if __name__ == "__main__":
    import sys
    import io
    import json
    import os
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    script_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(script_dir, "check_data.json")
    raw_path = os.path.join(script_dir, "references_raw.txt")

    # 模式选择：优先原始文本 → JSON
    if os.path.exists(raw_path):
        print(f"[数据来源] 原始引用文本: {raw_path}\n")
        with open(raw_path, "r", encoding="utf-8") as f:
            raw_text = f.read()
        records = parse_references_batch(raw_text)
    elif os.path.exists(json_path):
        print(f"[数据来源] JSON 文件: {json_path}\n")
        with open(json_path, "r", encoding="utf-8") as f:
            records = json.load(f)
    else:
        print("错误: 找不到数据文件！请在同目录下放置 check_data.json 或 references_raw.txt")
        sys.exit(1)

    results = check_batch(records)

    # 逐条打印
    for i, rec in enumerate(records):
        r = results[i]
        status = "[OK]" if r.passed else "[FAIL]"
        title = rec.get('title', '')
        year = rec.get('year', '')
        title_len = len(title) if title else 0
        print(f"[{i+1}] {status} 标题({title_len}字) 年份={year}")
        if r.errors:
            for e in r.errors:
                print(f"      -> {e}")
        # 如果标题或年份解析失败，给出提示
        if not title:
            print(f"      [解析失败] 未能提取标题，原文: {rec.get('raw', '')[:80]}...")
        if year is None:
            print(f"      [解析失败] 未能提取年份，原文: {rec.get('raw', '')[:80]}...")

    print()
    report_text = report(results)
    print(report_text)

    # 保存报告
    report_path = os.path.join(script_dir, "检查报告.txt")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report_text)
    print(f"\n报告已保存至: {report_path}")
